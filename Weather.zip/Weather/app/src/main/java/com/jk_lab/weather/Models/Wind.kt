package com.jk_lab.weather.Models

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)