package com.jk_lab.weather.Models

data class Rain(
    val `1h`: Double
)