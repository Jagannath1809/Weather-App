package com.jk_lab.weather.Models

data class Coord(
    val lat: Double,
    val lon: Double
)